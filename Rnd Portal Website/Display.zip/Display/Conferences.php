<h1>Conferences
<br>
<br>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "r&d";

$conn = new mysqli($servername, $username, $password, $dbname);

if($conn->connect_error)
{
    die("Connection Failed: ".$conn->connect_error);
}


$sql="SELECT * FROM conferences" ;
$result = $conn->query($sql);

?>
<html>
<head>
<title> Conferences</title>
<body>
<table width="600" border ="1" cellpadding="1" cellspacing="1">
<tr>

<th>Date From</th>
<th>Date To</th>
<th>Title</th>
<th>Broad Area</th>
<th>Edit/Delete</th>

<tr>



<?php

while($employee=$result->fetch_assoc()){

    echo "<tr>";
    echo "<td>".$employee['Date_From']."</td>";
    echo "<td>".$employee['Date_to']."</td>";
    echo "<td>".$employee['Title']."</td>";
    echo "<td>".$employee['Broad_area']."</td>";
    
    echo "<td>";

?>

<button type="submit"  formtarget="editframe">Edit</button>
   <a href="http://localhost/mis/mispages/Qualification.php"><input type="submit" value="Delete"></a>

  <?php  
  echo "</td>";
  echo "</tr>";
}
?> 

</table>
<br>
<center>
<a href="qual.php" ><button type="submit" src="qual.php" formtarget="_self" >Addnew</button></a>

<iframe id="editframe" src="qual.php" id="frame" width="100%" height="480px"  scrolling="yes">

</iframe>

</center>
</body>
</html>