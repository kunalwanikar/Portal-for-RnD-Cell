
 $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {

        var href = $(e.target).attr('href');
        var $curr = $(".process-model  a[href='" + href + "']").parent();

        $('.process-model li').removeClass();

        $curr.addClass("active");
        $curr.prevAll().addClass("visited");
        });

 $(".sidebar-dropdown > a").click(function() {
                $(".sidebar-submenu").slideUp(200);
                if (
                  $(this)
                    .parent()
                    .hasClass("active")
                ) {
                  $(".sidebar-dropdown").removeClass("active");
                  $(this)
                    .parent()
                    .removeClass("active");
                } else {
                  $(".sidebar-dropdown").removeClass("active");
                  $(this)
                    .next(".sidebar-submenu")
                    .slideDown(200);
                  $(this)
                    .parent()
                    .addClass("active");
                }
              });
              
              $("#close-sidebar").click(function() {
                $(".page-wrapper").removeClass("toggled");
              });
              $("#show-sidebar").click(function() {
                $(".page-wrapper").addClass("toggled");
              });
              
              

